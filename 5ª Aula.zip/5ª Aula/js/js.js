// document.addEventListener("DOMContentLoaded", function(){
//     document.getElementById("loginForm").addEventListener("submit", function(event){
//         event.preventDefault();
//         const username = document.getElementById("username").value;
//         const pass = document.getElementById("pass").value;
//         if(username === "usuario" && pass ==="senha"){
//             document.getElementById("message").textContent = "Login feito com sucesso";
//             window.location.href="home.html";
//         }else{
//             document.getElementById("message").textContent = "Login n�o realizado";
//         }
//     });
// });
