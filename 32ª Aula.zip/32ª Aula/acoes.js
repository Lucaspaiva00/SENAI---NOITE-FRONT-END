// function somar() {
//     let n1 = Number(window.prompt('Digite um número: '))
//     let n2 = Number(window.prompt('Digite outro número:'))


//     let res = document.querySelector('section#res')
//     res.innerHTML = `<p>A soma entre <mark>${n1}</mark> e <mark>${n2}</mark> é igual a <strong>${n1 + n2}</strong>!</p>`
// }

// function subtrair(){
//     let n1 = Number(window.prompt('Digite um número:'))
//     let n2 = Number(window.prompt('Digite outro número'))

//     let res_menos = document.querySelector('section#res_menos')
//     res_menos.innerHTML =`<span>A subtração entre <h1>
//     ${n1} </h1> <span> menos <h1>${n2}</h1> é igual a <h1>${n1-n2}</h1>`
// }

// function multiplicacao(){
//     let n1 = Number(window.prompt('Digite um número:'))
//     let n2 = Number(window.prompt('Digite outro número:'))
//     let res_sub = document.querySelector('section#res_sub')
//     res_sub.innerHTML = `<span>A multiplicação entre <h1>
//     ${n1} </h1> <span> x <h1>${n2}</h1> é igual a <h1>${n1*n2}</h1>`
// }

function divisao() {
    let n1 = Number(window.prompt('Digite um numero:'))
    let n2 = Number(window.prompt('Digite outro numero:'))

    let res_divisao = document.querySelector('section#res_divisao')

    res_divisao.innerHTML = `<p><span style="color:blue; border: 1px solid black; padding: 10px; border-radius:15px">A divisao entre
    ${n1}/${n2}e igual a ${n1 / n2}</span>`
}